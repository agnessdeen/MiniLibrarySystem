# demo.py
from operations import *

print(add_book("978001", "Python Basics", "John Doe", "Non-Fiction", 3))
print(add_member(1, "Agness Kabia", "agness@email.com"))
print(search_books("Python"))
print(borrow_book(1, "978001"))
print(return_book(1, "978001"))
