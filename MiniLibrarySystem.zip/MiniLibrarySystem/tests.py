# tests.py
from operations import *

def run_tests():
    assert add_book("978002", "Data Science", "Jane Doe", "Fiction", 2) == "Book added successfully."
    assert add_member(2, "John Smith", "john@email.com") == "Member added successfully."
    assert borrow_book(2, "978002") == "Book borrowed successfully."
    assert return_book(2, "978002") == "Book returned successfully."
    assert delete_book("978002") == "Book deleted."
    print("All tests passed successfully!")

run_tests()
