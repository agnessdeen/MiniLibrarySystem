# operations.py

books = {}
members = []
genres = ("Fiction", "Non-Fiction", "Sci-Fi")

# 1. Add a book
def add_book(isbn, title, author, genre, total_copies):
    if isbn in books:
        return "Book already exists."
    if genre not in genres:
        return "Invalid genre."
    books[isbn] = {"title": title, "author": author, "genre": genre, "total_copies": total_copies}
    return "Book added successfully."

# 2. Add a member
def add_member(member_id, name, email):
    for m in members:
        if m["member_id"] == member_id:
            return "Member already exists."
    members.append({"member_id": member_id, "name": name, "email": email, "borrowed_books": []})
    return "Member added successfully."

# 3. Search book
def search_books(keyword):
    results = []
    for isbn, book in books.items():
        if keyword.lower() in book["title"].lower() or keyword.lower() in book["author"].lower():
            results.append({isbn: book})
    return results

# 4. Update book/member
def update_book(isbn, title=None, author=None, genre=None, total_copies=None):
    if isbn not in books:
        return "Book not found."
    if title: books[isbn]["title"] = title
    if author: books[isbn]["author"] = author
    if genre and genre in genres: books[isbn]["genre"] = genre
    if total_copies: books[isbn]["total_copies"] = total_copies
    return "Book updated successfully."

# 5. Delete book/member
def delete_book(isbn):
    if isbn in books:
        del books[isbn]
        return "Book deleted."
    return "Book not found."

# 6. Borrow book
def borrow_book(member_id, isbn):
    for m in members:
        if m["member_id"] == member_id:
            if len(m["borrowed_books"]) >= 3:
                return "Borrow limit reached."
            if isbn not in books:
                return "Book not found."
            if books[isbn]["total_copies"] <= 0:
                return "No copies left."
            books[isbn]["total_copies"] -= 1
            m["borrowed_books"].append(isbn)
            return "Book borrowed successfully."
    return "Member not found."

# 7. Return book
def return_book(member_id, isbn):
    for m in members:
        if m["member_id"] == member_id:
            if isbn in m["borrowed_books"]:
                m["borrowed_books"].remove(isbn)
                books[isbn]["total_copies"] += 1
                return "Book returned successfully."
            return "Book not borrowed by this member."
    return "Member not found."
