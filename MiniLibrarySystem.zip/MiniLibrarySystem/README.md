# Mini Library Management System
A simple Python-based system to manage books and members.

## How to Run
1. Run `demo.py` to see sample operations.
2. Run `tests.py` to execute all unit tests.

## Files
- operations.py → core functions
- demo.py → demonstration
- tests.py → test cases
- UML.png → data structure diagram
- DesignRationale.pdf → explanation of design choices
